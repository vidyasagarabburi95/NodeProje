const mongoose=require('mongoose')
const dotenv=require('dotenv')
const fs=require('fs')
dotenv.config({ path: './config.env' });
const Movie=require('./../Model/movieModel')
// Connecting with remote database
mongoose.connect(process.env.CONN_STR, {
    useUnifiedTopology: true,
    useNewUrlParser: true // Optional, but can be included for backward compatibility
  })
    .then(() => {
      console.log('DB connection successful');
    })
    .catch((err) => {
      console.error('Error connecting to the database:', err.message);
    });
    
const movies=JSON.parse(fs.readFileSync('./Data/movies.json','utf-8'))
//DELETE EXISTING DOCUMENTS FROM COLLECTIONS

const deleteMovies=async()=>{
  try{
    await Movie.deleteMany();
    console.log('data success fully deletd')
  }catch(err){
    console.log(err.message)
  }
  process.exit()    
}
//IMPORT MOVIES DATA TO MONGODB COLLECTIONS
const importMovies=async()=>{
    try{
      await Movie.create(movies);
      console.log('data success fully deletd')
    }catch(err){
      console.log(err.message)
      process.exit()
    }
    process.exit()
  }


if(process.argv[2]==='--import'){
    importMovies()
}
if(process.argv[2]=='--delete'){
    deleteMovies()
}