const express = require('express');
const moviesController = require('../controllers/moviesController');
const authController=require('../controllers/authController')

const router = express.Router();

router.route('/highest-rated').get(moviesController.getHighestRated, moviesController.getAllMovies);
router.route('/movie-stats').get(moviesController.getMovieStatics);
router.route('/movies-by-genre/:genre').get(moviesController.getMovieByGenre);
router.route('/')
    .get(authController.protect,moviesController.getAllMovies)
    .post(moviesController.postMovie);

router.route('/:id')
    .get(authController.protect,moviesController.getSingleMovie)
    .patch(moviesController.patchMovie)
    .delete(authController.protect,authController.restrict('admin','test1'),moviesController.deleteMovie);

module.exports = router;
