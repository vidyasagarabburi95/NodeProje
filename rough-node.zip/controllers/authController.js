const CustomError = require("../Utils/customError");
const User = require("./../Model/userModel");
const asyncErrorHandler = require("./../Utils/asyncErrorHandler");
const jwt = require("jsonwebtoken");
const util = require("util");
const crypto=require('crypto')
const sendEmail = require("./../Utils/email");
const signToken = (id) => {
  return jwt.sign({ id }, process.env.SECRET_STR, {
    expiresIn: process.env.LOGIN_EXPIRES,
  });
};
exports.signup = asyncErrorHandler(async (req, res, next) => {
  const newUser = await User.create(req.body);
  const token = signToken(newUser._id);
  res.status(201).json({
    status: "success",
    token,
    data: {
      user: newUser,
    },
  });
});

/*exports.login = asyncErrorHandler(async (req, res, next) => {
  const email = req.body.email;
  const password = req.body.password;
  //const {email,password}=req.body
  //checks if email& password is present in request body
  if (!email || !password) {
    const error = new CustomError(
      "Please Provide email id and password for login in!",
      400
    );
    return next(error);
  }
  //checks if user exists with given email
  const user = await User.findOne({ email }).select("+password");
  //const isMatch =await user.comparePasswordInDb(password,user.password)
  //checks if the user exists & passwordmatches
  if (!user || (await user.comparePasswordInDb(password, user.password))) {
    const error = new CustomError("incorrect email or password ", 400);
    return next(error);
  }
  const token=signToken(user._id)
  res.status(200).json({
    status: "success",
    token
    
  });
});*/

exports.login = asyncErrorHandler(async (req, res, next) => {
  const { email, password } = req.body;

  // Check if email and password are provided
  if (!email || !password) {
    return next(
      new CustomError("Please provide email and password for login!", 400)
    );
  }

  // Find the user by email and explicitly select the password field
  const user = await User.findOne({ email }).select("+password");

  // Check if user exists and the password is correct
  if (!user || !(await user.comparePasswordInDb(password, user.password))) {
    return next(new CustomError("Incorrect email or password", 400));
  }

  // Generate the token and respond with success if the credentials are valid
  const token = signToken(user._id);
  res.status(200).json({
    status: "success",
    token,
  });
});

exports.protect = asyncErrorHandler(async (req, res, next) => {
  //1.read the token & check if it is exist
  const testToken = req.headers.authorization;
  console.log(testToken);
  let token;
  if (testToken && testToken.startsWith("Bearer")) {
    token = testToken.split(" ")[1];
  }
  if (!token) {
    return next(new CustomError("you are not logged in ", 401));
  }
  console.log(token);
  //2.validate token
  const decodedToken = await util.promisify(jwt.verify)(
    token,
    process.env.SECRET_STR
  );
  console.log(decodedToken);
  //3. if the user is existed or not
  const user = await User.findById(decodedToken.id);
  if (!user) {
    const error = new CustomError(
      "The user with given token does not exist",
      401
    );
    next(error);
  }
  const isPasswordChanged = await user.isPasswordChanged(decodedToken.iat);
  //4. if the user changed password after the token is issued
  if (isPasswordChanged) {
    const error = new CustomError(
      "the password has changed recently.please login again",
      401
    );
    return next(error);
  }
  //5. allow user access the route
  req.user = user;
  next();
});

exports.restrict = (role) => {
  return (req, res, next) => {
    if (req.user.role !== role) {
      //403--forbidden
      const error = new CustomError(
        "you do not have permission to perform this action",
        403
      );
      next();
    }
  };
};

//when multiple users want to acess the authorizatation to do some tasks in that way
/**exports.restrict=(...role)=>{
  return (req,res,next)=>{
    if(!role.includes(req.user.role)){
      //403--forbidden
      const error=new CustomError("you do not have permission to perform this action",403);
      next();
    }
  }
}
*/

exports.forgotPassword = asyncErrorHandler(async (req, res, next) => {
  //1.GET A USER BASED ON POSTED EMAIL
  const user = await User.findOne({ email: req.body.email });
  if (!user) {
    const error = new CustomError(
      "we could not find the user with given email",
      404
    );
    next(error);
  }
  //2.GENERATE RANDOM RESET TOKEN--we need reusable function we need an instance we can call user object in userModel createResetPasswordToken\
  const resetToken = user.createResetPasswordToken();
  await user.save({ validateBeforeSave: false });
  //3.SEND THE TOKEN BACK TO THE USER EMAIL
  const resetUrl = `${req.protocol}://${req.get(
    "host"
  )}/api/v1/users/resetPassword/${resetToken}`;
  const message = `we have a recieved password reset request.Please use the below link to reset password\n\n${resetUrl}\n\n this password reset link only valid for 10 min`;
  try {
    await sendEmail({
      email: user.email,
      subject: "password change request recieved",
      message: message,
    });
    res.status(200).json({
      status: "success",
      message: "password reset link send to the user email",
    });
  } catch (err) {
    user.passwordResetToken = undefined;
    user.passwordResetTokenExpires = undefined;
    user.save({ validateBeforeSave: false });
    return next(
      new CustomError(
        "There was an error sending password reset email.please try again later",
        500
      )
    );
  }
});

exports.resetPassword = asyncErrorHandler(async (req, res, next) => {
  //1.IF THE USER EXIST WITH THE GIVEN TOKEN and TOKEN HAS NOT EXPIRED
  const token = crypto
    .createHash("sha256")
    .update(req.params.token)
    .digest("hex");
  const user = await User.findOne({
    passwordResetToken: req.params.token,
    passwordResetTokenExpires: { $gt: Date.now() },
  });
  if(!user){
    const error=new CustomError('Token is invalid or expired!',400)
    next(error);
  }
  //2.RESTTING THE USER PASSWORD
  user.password=req.body.password;
  user.confirmPassword=req.body.confirmPassword;
  user.passwordResetToken=undefined;
  user.passwordResetTokenExpires=undefined;
  user.passwordChangedAt=Date.now();
  user.save();
  //3.login the user
  const loginToken=signToken(user._id);
  res.status(200).json({
    status:"success",
    token:loginToken
  })
});
