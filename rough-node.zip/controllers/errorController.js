const CustomError = require('../Utils/customError');
const customError = require('../Utils/customError');

const devErrors = (res, error) => {
    res.status(error.statusCode).json({
        status: error.statusCode,
        message: error.message,
        stackTrace: error.stack,
        error: error
    });
};

const productionError = (res, error) => {
    if (error.isOperational) {
        res.status(error.statusCode).json({
            status: error.statusCode,
            message: error.message,
        });
    } else {
        console.error('Unexpected Error:', error);
        res.status(500).json({
            status: 'error',
            message: 'Something went wrong, please try again later.'
        });
    }
};

const handleJwtError=(err)=>{
    return new CustomError("Invalid Token.please login again",401)

}

const handleExpiredJWT=(error)=>{
   return new CustomError('jwt has expired.please login again',401)
}

// Handle Mongoose CastError
const castErrorHandler = (err) => {
    const msg = `Invalid value for  ${err.path}: ${err.value}!`;
    return new customError(msg, 400);
};

const validationErrorHandler=(err)=>{
    console.log(Object.values(err.errors))

   const errors=Object.values(err.errors).map((val)=>val.message)
   const errorMessages=errors.join('. ')
   const msg=`Invalid input data :${errorMessages}`
   return new customError(msg,400)
  }
/*const duplicateKeyHandler = (error) => {
    const keyPattern = /duplicate key error(?: collection:| key: )/i;
    if (keyPattern.test(error.message)) {
        const key = error.message.match(/key: { : "([^"]+)"/)[1];
        const msg = `There is already a movie with name "${key}". Please use another name!`;
        return new customError(msg, 400);
    }
    // If the error message doesn't match the pattern, return a general error
    return new customError('Duplicate key error occurred', 400);
};*/

const duplicateKeyHandler=(error)=>{
    const name=error.keyValue.name;
    //const name = error.keyValue ? error.keyValue.name : 'unknown';
    //const name = error.keyValue && error.keyValue.name ? error.keyValue.name : 'unknown';
    console.log(name)
    const msg=`There is already a movie with name ${name} please use another name !`
    //console.log(name)
  return new customError(msg,400)
}

// Global error handling middleware
//when we add err,req,res,next express automatically detects for error handling global error handling object
module.exports = (error, req, res, next) => {
    // Ensure statusCode and status are set
    error.statusCode = error.statusCode || 500;
    error.status = error.status || 'error';

    // Check the environment
    if (process.env.NODE_ENV === 'development') {
        devErrors(res, error);
    } else if (process.env.NODE_ENV === 'production') {
        // Handle CastError
        if (error.name === 'CastError') error = castErrorHandler(error);
        if(error.code===11000) {
            error=duplicateKeyHandler(error)
            console.log(error)           
        }
        if(error.name==='ValidationError') error=validationErrorHandler(error);
             // Ensure that error has a valid statusCode
        if (!error.statusCode || error.statusCode < 100 || error.statusCode > 599) {
            error.statusCode = 400;
        }
        if (error.name === 'TokenExpiredError') error = handleExpiredJWT(error);
        if (error.name === 'JsonWebTokenError') error = handleJwtError(error);
        if (!error.statusCode || error.statusCode < 100 || error.statusCode > 599) {
            error.statusCode = 500;
        }
        
        productionError(res, error);
    }
};