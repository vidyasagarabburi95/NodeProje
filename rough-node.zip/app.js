const express = require('express');
const morgan = require('morgan');
const path = require('path');
const moviesRouter = require('./Routes/moviesRoute');
const authRouter=require('./Routes/authRouter')
const CustomError=require('./Utils/customError')
const globalErrorHandler=require('./controllers/errorController')


const app = express();

// Middleware to parse JSON bodies
app.use(express.json());

// Custom logger middleware
const logger = (req, res, next) => {
    console.log('Custom middleware called');
    next();
};

app.use(logger);

// Morgan logging middleware
app.use(morgan('dev'));
app.use(express.static('./public'))

// Middleware to add requested time
app.use((req, res, next) => {
    req.requestedAt = new Date().toISOString();
    next();
});

// Use the movies router
app.use('/api/v1/movies', moviesRouter);
app.use('/api/v1/users', authRouter);

app.all('*',(req,res,next)=>{
  //res.status(404).json({
    //status:'fail',     ---1st time written code
    //message:`can't find ${req.originalUrl} on the server`
    //const err=new Error(`can't find ${req.originalUrl} on the server`)---2nd time updated
    //err.status='fail';
    //err.statusCode=404
    //next(err)
    const err=new CustomError(`can't find ${req.originalUrl} on the server`,404)//---3rd time with custom handler
    next(err)
  })
//}) //* to handle invalid api request
//when we add err,req,res,next express automatically detects for error handling global error handling object
app.use(globalErrorHandler)
// Create server
module.exports=app