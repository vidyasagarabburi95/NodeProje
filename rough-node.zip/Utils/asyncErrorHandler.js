
module.exports=(func) => {
    return (req,res,next)=>{
        func(req, res, next).catch((err) => next(err));//in this we calling global error hanfdling middleware
    }
  
};
//for handling async error handling in this we need to pass another function as an argument in to this function