class CustomError extends Error{
    constructor(message,statuscode){
        super(message);
         this.statuscode=statuscode
         this.status=statuscode>=400 && statuscode<=500 ?'fail':'error'

         this.isOperational=true

         Error.captureStackTrace(this,this.constructor) //it actually tells the where is the error happend in the code and to preserve the error we are using this

    }

}
module.exports=CustomError
//const error=new CustomError('some error message 404')